

function Edificio(calle, numero, codigoPostal) {
  this.calle = calle;
  this.numero = numero;
  this.codigoPostal = codigoPostal;
  this.plantas = [];
  console.log(`Construido nuevo edificio en calle: ${calle}, nº: ${numero}, CP: ${codigoPostal}.`);
}

Edificio.prototype.agregarPlantasYPuertas = function(numPlantas, puertas) {
  for (let i = 0; i < numPlantas; i++) {
    let planta = [];
    for (let j = 0; j < puertas; j++) {
      planta.push({ propietario: null });
    }
    this.plantas.push(planta);
  }
};

Edificio.prototype.modificarNumero = function(numero) {
  this.numero = numero;
};

Edificio.prototype.modificarCalle = function(calle) {
  this.calle = calle;
};

Edificio.prototype.modificarCodigoPostal = function(codigo) {
  this.codigoPostal = codigo;
};

Edificio.prototype.imprimeCalle = function() {
  return this.calle;
};

Edificio.prototype.imprimeNumero = function() {
  return this.numero;
};

Edificio.prototype.imprimeCodigoPostal = function() {
  return this.codigoPostal;
};

Edificio.prototype.agregarPropietario = function(nombre, planta, puerta) {
  this.plantas[planta - 1][puerta - 1].propietario = nombre;
  console.log(`${nombre} es ahora el propietario de la puerta ${puerta} de la planta ${planta}.`);
};

Edificio.prototype.imprimePlantas = function() {
  console.log(`Listado de propietarios del edificio en ${this.calle} ${this.numero}\n`);
  for (let i = 0; i < this.plantas.length; i++) {
    for (let j = 0; j < this.plantas[i].length; j++) {
      const propietario = this.plantas[i][j].propietario || "Sin propietario";
      console.log(`Propietario del piso ${j + 1} de la planta ${i + 1}: ${propietario}.`);
    }
  }
};

// Ejemplo de uso
const edificio1 = new Edificio("Garcia Prieto", 58, 15706);
edificio1.agregarPlantasYPuertas(2, 3);
edificio1.agregarPropietario("Juan Pérez", 1, 1);
edificio1.agregarPropietario("María Rodríguez", 1, 2);
edificio1.imprimePlantas();

// Instanciamos 3 objetos edificioA, edificioB y edificioC con estos datos:
const edificioA = new Edificio("Garcia Prieto", 58, 15706);
const edificioB = new Edificio("Camino Caneiro", 29, 32004);
const edificioC = new Edificio("San Clemente", "s/n", 15705);

// El código postal del edificio A es: 15706.
console.log(`El código postal del edificio A es: ${edificioA.imprimeCodigoPostal()}.`);

// La calle del edificio C es: San Clemente.
console.log(`La calle del edificio C es: ${edificioC.imprimeCalle()}.`);

// El edificio B está situado en la calle Camino Caneiro número 29.
console.log(`El edificio B está situado en la calle ${edificioB.imprimeCalle()} número ${edificioB.imprimeNumero()}.`);

// Agregamos 2 plantas y 3 puertas por planta al edificio A...
edificioA.agregarPlantasYPuertas(2, 3);

// Agregamos 4 propietarios al edificio A...
edificioA.agregarPropietario("Jose Antonio Lopez", 1, 1);
edificioA.agregarPropietario("Luisa Martinez", 1, 2);
edificioA.agregarPropietario("Marta Castellón", 1, 3);
edificioA.agregarPropietario("Antonio Pereira", 2, 2);
