// Función para incrementar el contador de intentos y mostrarlo en el contenedor "intentos"
function incrementarIntentos() {
    // Obtener el valor actual de la cookie
    let intentos = parseInt(getCookie("intentos")) || 0;
  
    // Incrementar el contador de intentos
    intentos++;
  
    // Guardar el nuevo valor en la cookie
    setCookie("intentos", intentos, 1); // 1 día de duración de la cookie
  
    // Mostrar el mensaje en el contenedor "intentos"
    document.getElementById("intentos").innerHTML = `Intento de Envíos del formulario: ${intentos}`;
  }
  
  // Función para convertir a mayúsculas el contenido de los campos NOMBRE y APELLIDOS al perder el foco
  function convertirAMayusculas(elemento) {
    elemento.value = elemento.value.toUpperCase();
  }
  
  // Función para validar los campos de texto NOMBRE y APELLIDOS
  function validarNombreApellido() {
    const nombre = document.getElementById("nombre").value;
    const apellidos = document.getElementById("apellidos").value;
  
    if (!nombre || !apellidos) {
      // Mostrar mensaje de error en el contenedor "errores"
      document.getElementById("errores").innerHTML = "Nombre y apellidos son campos obligatorios.";
      
      // Poner el foco en los campos correspondientes
      if (!nombre) {
        document.getElementById("nombre").focus();
      } else {
        document.getElementById("apellidos").focus();
      }
  
      return false; // Indicar que hay errores
    }
  
    return true; // Indicar que la validación fue exitosa
  }
  
  // Función para validar la EDAD
  function validarEdad() {
    const edad = document.getElementById("edad").value;
  
    if (isNaN(edad) || edad < 0 || edad > 105) {
      // Mostrar mensaje de error en el contenedor "errores"
      document.getElementById("errores").innerHTML = "La edad debe ser un valor numérico entre 0 y 105.";
      
      // Poner el foco en el campo EDAD
      document.getElementById("edad").focus();
  
      return false; // Indicar que hay errores
    }
  
    return true; // Indicar que la validación fue exitosa
  }
  
  // Función para validar el NIF
  function validarNIF() {
    const nif = document.getElementById("nif").value;
    const regexNIF = /^\d{8}-[a-zA-Z]$/; // Explicación en comentarios más abajo
  
    if (!regexNIF.test(nif)) {
      // Mostrar mensaje de error en el contenedor "errores"
      document.getElementById("errores").innerHTML = "El NIF debe tener 8 números, un guión y una letra.";
      
      // Poner el foco en el campo NIF
      document.getElementById("nif").focus();
  
      return false; // Indicar que hay errores
    }
  
    return true; // Indicar que la validación fue exitosa
  }
  
  // Función para validar el E-MAIL
  function validarEmail() {
    const email = document.getElementById("email").value;
    const regexEmail = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/; // Explicación en comentarios más abajo
  
    if (!regexEmail.test(email)) {
      // Mostrar mensaje de error en el contenedor "errores"
      document.getElementById("errores").innerHTML = "El formato del correo electrónico no es válido.";
      
      // Poner el foco en el campo E-MAIL
      document.getElementById("email").focus();
  
      return false; // Indicar que hay errores
    }
  
    return true; // Indicar que la validación fue exitosa
  }
  
  // ... (Funciones de validación para PROVINCIA, FECHA, TELEFONO, HORA, etc.)
  
  // Función para pedir confirmación antes de enviar el formulario
  function confirmarEnvio() {
    const confirmacion = confirm("¿Estás seguro de enviar el formulario?");
  
    if (confirmacion) {
      // Incrementar el contador de intentos y mostrarlo en el contenedor "intentos"
      incrementarIntentos();
      
      // Realizar el envío del formulario
      document.getElementById("formulario").submit();
    } else {
      // Cancelar el envío del formulario
      alert("Envío cancelado.");
    }
  }
  
  // Función para establecer una cookie
  function setCookie(nombre, valor, dias) {
    const fecha = new Date();
    fecha.setTime(fecha.getTime() + (dias * 24 * 60 * 60 * 1000));
    const expiracion = "expires=" + fecha.toUTCString();
    document.cookie = nombre + "=" + valor + ";" + expiracion + ";path=/";
  }
  
  // Función para obtener el valor de una cookie
  function getCookie(nombre) {
    const nombreCooke = nombre + "=";
    const cookies = document.cookie.split(';');
  
    for (let i = 0; i < cookies.length; i++) {
      let cookie = cookies[i];
      while (cookie.charAt(0) == ' ') {
        cookie = cookie.substring(1);
      }
      if (cookie.indexOf(nombreCooke) == 0) {
        return cookie.substring(nombreCooke.length, cookie.length);
      }
    }
  
    return "";
  }
  
  // Función para validar campos al perder el foco
  function validarCampoAlPerderFoco(elemento, validacionFunc) {
    elemento.addEventListener("blur", function() {
      validacionFunc();
    });
  }
  
  // Asociar las funciones de validación a los campos correspondientes al perder el foco
  validarCampoAlPerderFoco(document.getElementById("nombre"), validarNombreApellido);
  validarCampoAlPerderFoco(document.getElementById("apellidos"), validarNombreApellido);
  validarCampoAlPerderFoco(document.getElementById("edad"), validarEdad);
  validarCampoAlPerderFoco(document.getElementById("nif"), validarNIF);
  validarCampoAlPerderFoco(document.getElementById("email"), validarEmail);
  
  // ... (Asociar funciones de validación para PROVINCIA, FECHA, TELEFONO, HORA, etc.)
  // ... (Código anterior)

// Validar la PROVINCIA
function validarProvincia() {
    const provincia = document.getElementById("provincia").value;
  
    if (!provincia) {
      // Mostrar mensaje de error en el contenedor "errores"
      document.getElementById("errores").innerHTML = "Debes seleccionar una provincia.";
      
      // Poner el foco en el campo PROVINCIA
      document.getElementById("provincia").focus();
  
      return false; // Indicar que hay errores
    }
  
    return true; // Indicar que la validación fue exitosa
  }
  
  // Asociar la función de validación a la PROVINCIA al perder el foco
  validarCampoAlPerderFoco(document.getElementById("provincia"), validarProvincia);
  
  // Validar la FECHA
  function validarFecha() {
    const fecha = document.getElementById("fecha").value;
    const regexFecha = /^(0[1-9]|[12][0-9]|3[01])[\/\-](0[1-9]|1[0-2])[\/\-]\d{4}$/; // Explicación en comentarios más abajo
  
    if (!regexFecha.test(fecha)) {
      // Mostrar mensaje de error en el contenedor "errores"
      document.getElementById("errores").innerHTML = "El formato de la fecha no es válido.";
      
      // Poner el foco en el campo FECHA
      document.getElementById("fecha").focus();
  
      return false; // Indicar que hay errores
    }
  
    return true; // Indicar que la validación fue exitosa
  }
  
  // Asociar la función de validación a la FECHA al perder el foco
  validarCampoAlPerderFoco(document.getElementById("fecha"), validarFecha);
  
  // Validar el TELEFONO
  function validarTelefono() {
    const telefono = document.getElementById("telefono").value;
    const regexTelefono = /^\d{9}$/; // Explicación en comentarios más abajo
  
    if (!regexTelefono.test(telefono)) {
      // Mostrar mensaje de error en el contenedor "errores"
      document.getElementById("errores").innerHTML = "El número de teléfono debe tener 9 dígitos.";
      
      // Poner el foco en el campo TELEFONO
      document.getElementById("telefono").focus();
  
      return false; // Indicar que hay errores
    }
  
    return true; // Indicar que la validación fue exitosa
  }
  
  // Asociar la función de validación al TELEFONO al perder el foco
  validarCampoAlPerderFoco(document.getElementById("telefono"), validarTelefono);
  
  // Validar la HORA
  function validarHora() {
    const hora = document.getElementById("hora").value;
    const regexHora = /^([01]?[0-9]|2[0-3]):[0-5][0-9]$/; // Explicación en comentarios más abajo
  
    if (!regexHora.test(hora)) {
      // Mostrar mensaje de error en el contenedor "errores"
      document.getElementById("errores").innerHTML = "El formato de la hora no es válido.";
      
      // Poner el foco en el campo HORA
      document.getElementById("hora").focus();
  
      return false; // Indicar que hay errores
    }
  
    return true; // Indicar que la validación fue exitosa
  }
  
  // Asociar la función de validación a la HORA al perder el foco
  validarCampoAlPerderFoco(document.getElementById("hora"), validarHora);
  
  // ... (Código anterior)
  
  // Asociar la función confirmarEnvio al evento submit del formulario
  document.getElementById("formulario").addEventListener("submit", function(event) {
    // Validar todos los campos antes de enviar
    const validacionGlobal =
      validarNombreApellido() &&
      validarEdad() &&
      validarNIF() &&
      validarEmail() &&
      validarProvincia() &&
      validarFecha() &&
      validarTelefono() &&
      validarHora();
  
    // Si la validación global falla, detener el envío del formulario
    if (!validacionGlobal) {
      event.preventDefault();
    } else {
      // Si la validación es exitosa, pedir confirmación antes de enviar
      confirmarEnvio();
    }
  });
  
  // Función para validar la FECHA
  function validarFecha() {
    const fecha = document.getElementById("fecha").value;
    const regexFecha = /^(0[1-9]|[12][0-9]|3[01])[\/\-](0[1-9]|1[0-2])[\/\-]\d{4}$/; // Explicación en comentarios más abajo
  
    if (!regexFecha.test(fecha)) {
      // Mostrar mensaje de error en el contenedor "errores"
      document.getElementById("errores").innerHTML = "El formato de la fecha no es válido.";
      
      // Poner el foco en el campo FECHA
      document.getElementById("fecha").focus();
  
      return false; // Indicar que hay errores
    }
  
    return true; // Indicar que la validación fue exitosa
  }
  
  // Asociar la función de validación a la FECHA al perder el foco
  validarCampoAlPerderFoco(document.getElementById("fecha"), validarFecha);
  
  // Validar el TELEFONO
  function validarTelefono() {
    const telefono = document.getElementById("telefono").value;
    const regexTelefono = /^\d{9}$/; // Explicación en comentarios más abajo
  
    if (!regexTelefono.test(telefono)) {
      // Mostrar mensaje de error en el contenedor "errores"
      document.getElementById("errores").innerHTML = "El número de teléfono debe tener 9 dígitos.";
      
      // Poner el foco en el campo TELEFONO
      document.getElementById("telefono").focus();
  
      return false; // Indicar que hay errores
    }
  
    return true; // Indicar que la validación fue exitosa
  }
  
  // Asociar
  // La función de validación para el TELEFONO al perder el foco
validarCampoAlPerderFoco(document.getElementById("telefono"), validarTelefono);

// Validar la HORA
function validarHora() {
  const hora = document.getElementById("hora").value;
  const regexHora = /^([01]?[0-9]|2[0-3]):[0-5][0-9]$/; // Explicación en comentarios más abajo

  if (!regexHora.test(hora)) {
    // Mostrar mensaje de error en el contenedor "errores"
    document.getElementById("errores").innerHTML = "El formato de la hora no es válido.";
    
    // Poner el foco en el campo HORA
    document.getElementById("hora").focus();

    return false; // Indicar que hay errores
  }

  return true; // Indicar que la validación fue exitosa
}

// Asociar la función de validación a la HORA al perder el foco
validarCampoAlPerderFoco(document.getElementById("hora"), validarHora);

// Asociar la función confirmarEnvio al evento submit del formulario
document.getElementById("formulario").addEventListener("submit", function(event) {
  // Validar todos los campos antes de enviar
  const validacionGlobal =
    validarNombreApellido() &&
    validarEdad() &&
    validarNIF() &&
    validarEmail() &&
    validarProvincia() &&
    validarFecha() &&
    validarTelefono() &&
    validarHora();

  // Si la validación global falla, detener el envío del formulario
  if (!validacionGlobal) {
    event.preventDefault();
  } else {
    // Si la validación es exitosa, pedir confirmación antes de enviar
    confirmarEnvio();
  }
});

// Función para validar la FECHA
function validarFecha() {
  const fecha = document.getElementById("fecha").value;
  const regexFecha = /^(0[1-9]|[12][0-9]|3[01])[\/\-](0[1-9]|1[0-2])[\/\-]\d{4}$/; // Explicación en comentarios más abajo

  if (!regexFecha.test(fecha)) {
    // Mostrar mensaje de error en el contenedor "errores"
    document.getElementById("errores").innerHTML = "El formato de la fecha no es válido.";
    
    // Poner el foco en el campo FECHA
    document.getElementById("fecha").focus();

    return false; // Indicar que hay errores
  }

  return true; // Indicar que la validación fue exitosa
}

// Asociar la función de validación a la FECHA al perder el foco
validarCampoAlPerderFoco(document.getElementById("fecha"), validarFecha);

// Validar el TELEFONO
function validarTelefono() {
  const telefono = document.getElementById("telefono").value;
  const regexTelefono = /^\d{9}$/; // Explicación en comentarios más abajo

  if (!regexTelefono.test(telefono)) {
    // Mostrar mensaje de error en el contenedor "errores"
    document.getElementById("errores").innerHTML = "El número de teléfono debe tener 9 dígitos.";
    
    // Poner el foco en el campo TELEFONO
    document.getElementById("telefono").focus();

    return false; // Indicar que hay errores
  }

  return true; // Indicar que la validación fue exitosa
}

// Asociar la función de validación al TELEFONO al perder el foco
validarCampoAlPerderFoco(document.getElementById("telefono"), validarTelefono);

// Validar la HORA
function validarHora() {
  const hora = document.getElementById("hora").value;
  const regexHora = /^([01]?[0-9]|2[0-3]):[0-5][0-9]$/; // Explicación en comentarios más abajo

  if (!regexHora.test(hora)) {
    // Mostrar mensaje de error en el contenedor "errores"
    document.getElementById("errores").innerHTML = "El formato de la hora no es válido.";
    
    // Poner el foco en el campo HORA
    document.getElementById("hora").focus();

    return false; // Indicar que hay errores
  }

  return true; // Indicar que la validación fue exitosa
}

// Asociar la función de validación a la HORA al perder el foco
validarCampoAlPerderFoco(document.getElementById("hora"), validarHora);

// ... (Código anterior)
