// Código para crear el tablero de dibujo
document.addEventListener("DOMContentLoaded", function () {
  var zonadibujo = document.getElementById("zonadibujo");
  var tablero = document.createElement("table");
  tablero.id = "tablerodibujo";

  for (var i = 0; i < 30; i++) {
    var fila = document.createElement("tr");
    for (var j = 0; j < 30; j++) {
      var celda = document.createElement("td");
      celda.addEventListener("mouseover", pintarCelda);
      fila.appendChild(celda);
    }
    tablero.appendChild(fila);
  }

  zonadibujo.appendChild(tablero);
});

function pintarCelda() {
  // Lógica para pintar la celda con el color seleccionado
  // Puedes obtener el color seleccionado revisando las clases de la paleta
}
document.addEventListener("DOMContentLoaded", function () {
  // ... (código anterior)

  // Agregar eventos de clic para los colores de la paleta
  var coloresPaleta = document.querySelectorAll("#paleta td");
  coloresPaleta.forEach(function (color) {
    color.addEventListener("click", seleccionarColor);
  });
});

function seleccionarColor(event) {
  // Lógica para cambiar el color activo y aplicar la clase "seleccionado"
  // Puedes usar event.target para obtener el color seleccionado
}

var pincelActivo = false;

function activarPincel() {
  // Lógica para activar el pincel y mostrar el mensaje
}

function desactivarPincel() {
  // Lógica para desactivar el pincel y mostrar el mensaje
}
var colorActivo = ""; // Variable para almacenar el color activo

function seleccionarColor(event) {
  // Lógica para cambiar el color activo y aplicar la clase "seleccionado"
  if (colorActivo !== "") {
    // Si ya hay un color activo, quitar la clase "seleccionado"
    var colorAnterior = document.querySelector(".seleccionado");
    colorAnterior.classList.remove("seleccionado");
  }

  // Obtener el color seleccionado
  colorActivo = event.target.style.backgroundColor;
  // Aplicar la clase "seleccionado" al color seleccionado
  event.target.classList.add("seleccionado");

  // Mostrar mensaje de pincel activado
  activarPincel();
}

function activarPincel() {
  // Lógica para activar el pincel y mostrar el mensaje
  pincelActivo = true;
  document.getElementById("pincel").textContent = "PINCEL ACTIVADO";
}

function desactivarPincel() {
  // Lógica para desactivar el pincel y mostrar el mensaje
  pincelActivo = false;
  document.getElementById("pincel").textContent = "PINCEL DESACTIVADO";
}

function pintarCelda(event) {
  // Lógica para pintar la celda con el color activo
  if (pincelActivo) {
    event.target.style.backgroundColor = colorActivo;
  }
}

// Agregar eventos de clic para activar y desactivar el pincel
document.getElementById("tablerodibujo").addEventListener("mousedown", activarPincel);
document.getElementById("tablerodibujo").addEventListener("mouseup", desactivarPincel);
document.getElementById("tablerodibujo").addEventListener("mouseleave", desactivarPincel);

// Lógica para manejar el color blanco y borrar una celda
document.getElementById("paleta").addEventListener("click", function (event) {
  if (event.target.classList.contains("color6")) {
    colorActivo = "#FFF";
    activarPincel();
  }
});
document.addEventListener("DOMContentLoaded", function () {
  // ... (código anterior)

  // Agregar evento de clic para el botón de pintar
  var botonPintar = document.getElementById("botonPintar");
  botonPintar.addEventListener("click", togglePintar);
});

function togglePintar() {
  // Lógica para activar/desactivar la funcionalidad de pintar
  if (!pincelActivo) {
    activarPincel();
  } else {
    desactivarPincel();
  }
}
function pintarCelda(event) {
  // Lógica para pintar la celda con el color activo
  if (pincelActivo) {
    event.target.style.backgroundColor = colorActivo;
  }
}
