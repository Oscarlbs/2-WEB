<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" style="color: aqua;">

    <center>
    <title>Presentación de la Aplicación</title>
</head>
<body style="background-color:rgb(122, 69, 69);" text="white">
    <header>
        <h1>Bienvenido a la Aplicación de correo</h1>
    </header>
    <section>
        <h2>Cometido de la Aplicación</h2>
        <p>Darse de alta introduciendo datos como el nombre o el correo electrónico, una vez hecho, se envían y se almacenan.</p>
    </section>
    <section>
        <h2>Funcionamiento</h2>
        <p>La aplicación es fácil de usar, simplemente sigue estos pasos:</p>
        <ol>
           <p></p>
            1. Introduce los datos. <p></p>
            2.Haz click en enviar. <p></p>
            3. Podrás ver la pagina con todos tus datos <p></p>
        </ol>
    </section>
    <footer>
        <p>¡Esperamos que disfrutes de nuestra aplicación! Para continuar haga click  <a href="segundapagina.php" style="color: rgb(255, 255, 255);"> AQUÍ</a>.</p>
    </footer>
    <img src="IMGS/mikaela-wiedenhoff-AwmCuTXL97Q-unsplash.jpg" width="500px" height="500px"/>
</body></center>
</html>

